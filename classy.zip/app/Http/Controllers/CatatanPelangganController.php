<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CatatanPelangganController extends Controller
{
    //
}
