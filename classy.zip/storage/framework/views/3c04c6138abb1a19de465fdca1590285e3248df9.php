<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<title>Classy</title>
<?php header('Access-Control-Allow-Origin: *'); ?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<script src="https://kit.fontawesome.com/118575507a.js" crossorigin="anonymous"></script>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php /**PATH D:\xampp\htdocs\classy\resources\views/includes/head.blade.php ENDPATH**/ ?>