<!doctype html>
<html>
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div id="content" class="w-100">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/layouts/guest.blade.php ENDPATH**/ ?>