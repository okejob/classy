<!doctype html>
<html>
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex">
        <?php echo $__env->make('includes.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="content" class="position-relative pb-5" style="max-height: calc(100vh - 60px); width: calc(100vw - 205px); overflow-y: auto;">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\classy\resources\views/layouts/users.blade.php ENDPATH**/ ?>