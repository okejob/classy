<header id="header" class="bg-main d-flex align-items-center justify-content-between px-2">
    <button class="btn" type="button">
        <i id="side-icon" class="fas fa-bars"></i>
    </button>
    <div class="d-flex align-items-center">
        <div class="position-relative me-3">
            <button class="btn btn-sm d-flex" type="button">
                <i class="fa-solid fa-bell" style="font-size: 1rem"></i>
            </button>
            
        </div>
        <div class="dropdown">
            <button class="btn dropdown-toggle" aria-expanded="false" data-bs-toggle="dropdown" type="button">
                <i class="fas fa-user-circle"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
            <?php if(Session::get('role') == 'administrator'): ?>
                <a class="dropdown-item" id="menu-outlet" data-outlet="<?php if(Auth::user()->outlet): ?><?php echo e(Auth::user()->outlet->id); ?><?php endif; ?>">Outlet</a>
            <?php endif; ?>
                <a class="dropdown-item" href="/logout">Log Out</a>
            </div>
        </div>
    </div>
</header>
<div class="modal fade" id="modal-pengaturan-outlet" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ganti Sesi Outlet</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form-pengaturan-outlet">
                <div class="modal-body" id="container-select-outlet">

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="btn-ganti-outlet">Ganti</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\classy\resources\views/includes/header.blade.php ENDPATH**/ ?>