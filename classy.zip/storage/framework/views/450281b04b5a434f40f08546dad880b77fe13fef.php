<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Outlet</th>
                <th>Membership</th>
                <th>Nama Lengkap</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Jenis ID</th>
                <th>Nomor ID</th>
                <th>Telphone</th>
                <th>E-mail</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Outlet Pelanggan</td>
                <?php if($pelanggan->member): ?>
                    <td class="text-center">Member</td>
                <?php else: ?>
                    <td class="text-center">Bukan member</td>
                <?php endif; ?>
                <td><?php echo e($pelanggan->nama); ?></td>
                <td class="text-center"><?php echo e($pelanggan->tanggal_lahir); ?></td>
                <td><?php echo e($pelanggan->alamat); ?></td>
                <td class="text-center"><?php echo e($pelanggan->jenis_id); ?></td>
                <td class="text-center"><?php echo e($pelanggan->no_id); ?></td>
                <td><?php echo e($pelanggan->telephone); ?></td>
                <td><?php echo e($pelanggan->email); ?></td>
                <?php if($pelanggan->status): ?>
                    <td class="text-center">Aktif</td>
                <?php else: ?>
                    <td class="text-center">Tidak aktif</td>
                <?php endif; ?>
                <td class="cell-action">
                    <button id="btn-<?php echo e($pelanggan->id); ?>" class="btn btn-primary btn-sm btn-show-action" type="button">
                        <i class="fas fa-bars"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php echo e($pelanggans->links()); ?>

<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/components/tablePelanggan.blade.php ENDPATH**/ ?>