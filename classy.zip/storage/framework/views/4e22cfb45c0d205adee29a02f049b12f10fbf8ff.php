<link rel="stylesheet" href="https://unpkg.com/intro.js/minified/introjs.min.css">
<script src="https://unpkg.com/intro.js/minified/intro.min.js"></script>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/includes/library/intro_js.blade.php ENDPATH**/ ?>