<div>
    <section id="section-ambil-outlet" class="mb-4">
        <h4>Ambil di outlet</h4>
        <hr />
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 10%;">ID</th>
                        <th style="width: 30%;">Penerima</th>
                        <th style="width: 20%;">Outlet</th>
                        <th>Tanggal Ambil</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambil_di_outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ambil_di_outlet->id); ?></td>
                            <td><?php echo e($ambil_di_outlet->penerima); ?></td>
                            <td><?php echo e($ambil_di_outlet->outlet->nama); ?></td>
                            <td><?php echo e($ambil_di_outlet->tanggal_penerimaan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/components/table-ambil-outlet.blade.php ENDPATH**/ ?>