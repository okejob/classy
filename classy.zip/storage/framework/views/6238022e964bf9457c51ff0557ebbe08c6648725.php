

<?php $__env->startSection('content'); ?>
    <div class="container">
        <header class="my-3" style="color: var(--bs-gray);">
            <a>Transaksi</a>
            <i class="fas fa-angle-right mx-2"></i>
            <a>Pickup &amp; Delivery</a>
        </header>
        <div class="card">
            <?php if (isset($component)) { $__componentOriginald901fb0ef041f461bcd607be5c946de8d32ba869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TablePickup::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table-pickup'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\TablePickup::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald901fb0ef041f461bcd607be5c946de8d32ba869)): ?>
<?php $component = $__componentOriginald901fb0ef041f461bcd607be5c946de8d32ba869; ?>
<?php unset($__componentOriginald901fb0ef041f461bcd607be5c946de8d32ba869); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalbe14d2297264e70d038bc40d0e9bc941ac79aed0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableDelivery::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table-delivery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\TableDelivery::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe14d2297264e70d038bc40d0e9bc941ac79aed0)): ?>
<?php $component = $__componentOriginalbe14d2297264e70d038bc40d0e9bc941ac79aed0; ?>
<?php unset($__componentOriginalbe14d2297264e70d038bc40d0e9bc941ac79aed0); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalbd00f5315a835e85fc5c12ef33c262845e48fe39 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableAmbilOutlet::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table-ambil-outlet'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\TableAmbilOutlet::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd00f5315a835e85fc5c12ef33c262845e48fe39)): ?>
<?php $component = $__componentOriginalbd00f5315a835e85fc5c12ef33c262845e48fe39; ?>
<?php unset($__componentOriginalbd00f5315a835e85fc5c12ef33c262845e48fe39); ?>
<?php endif; ?>
        </div>
    </div>
    <div role="dialog" tabindex="-1" class="modal fade" id="modal-create-pickup">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Create Pickup</h4><button type="button" class="btn-close"
                        data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/transaksi/pickup-delivery" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-6 mb-2">
                                <h5>Pilih Pelanggan</h5>
                                <select class="form-control" name="pelanggan_id" required>
                                    <option value="" selected hidden>-</option>
                                    <?php $__currentLoopData = $dataPelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pelanggan->id); ?>"><?php echo e($pelanggan->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-6 mb-2">
                                <h5>Pilih Driver</h5>
                                <select class="form-control" name="driver_id" required>
                                    <option value="" selected hidden>-</option>
                                    <?php $__currentLoopData = $dataDriver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->username); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12 mb-2">
                                <h5>Alamat</h5>
                                <input type="text" class="form-control" name="alamat" required />
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="action" value="pickup">
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div role="dialog" tabindex="-1" class="modal fade" id="modal-create-delivery">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Create Delivery</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/transaksi/pickup-delivery" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-6 mb-2" id="col-transaksi">
                                <h5>Pilih Transaksi</h5>
                                <select class="form-control" name="transaksi_id" required>
                                    <option value="" selected hidden>-</option>
                                    <?php $__currentLoopData = $dataTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($trans->id); ?>"><?php echo e($trans->kode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-6 mb-2">
                                <h5>Pilih Driver</h5>
                                <select class="form-control" name="driver_id" required>
                                    <option value="" selected hidden>-</option>
                                    <?php $__currentLoopData = $dataDriver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->username); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12 mb-2">
                                <h5>Alamat</h5>
                                <input type="text" class="form-control" name="alamat" required />
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="action" value="delivery">
                    <div class="modal-footer">
                        <button class="btn btn-primary" type="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <script src="<?php echo e(asset('js/transaksi/pickupDelivery.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/pages/transaksi/PickupDelivery.blade.php ENDPATH**/ ?>