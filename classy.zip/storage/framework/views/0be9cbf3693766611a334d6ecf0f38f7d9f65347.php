<div>
    <div class="card-body">
        <section id="section-pickup" class="mb-4">
            <h4>Pickup</h4>
            <hr />
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 10%;">ID</th>
                            <th style="width: 30%;">Pelanggan</th>
                            <th style="width: 20%;">Driver</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($pickup->id); ?></td>
                                <td class="text-center"><?php echo e($pickup->pelanggan->nama); ?></td>
                                <td class="text-center"><?php echo e($pickup->nama_driver); ?></td>
                                <td><?php echo e($pickup->alamat); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end">
                <button id="create-pickup" class="btn btn-primary">Pickup Baru</button>
            </div>
            <?php echo e($data1->links()); ?>

        </section>
        <hr style="margin: 1rem -1rem;" />
    </div>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/components/table-pickup.blade.php ENDPATH**/ ?>