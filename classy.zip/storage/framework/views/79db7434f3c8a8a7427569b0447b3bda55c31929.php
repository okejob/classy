

<?php $__env->startSection('content'); ?>
<style>
    #nama-pelanggan::-webkit-calendar-picker-indicator {
        display: none!important;
    }
</style>

<div class="container">
    <section id="section-transaksi-saldo">
        <header class="my-3" style="color: var(--bs-gray);"><a>Transaksi</a><i class="fas fa-angle-right mx-2"></i><a>Saldo</a></header>
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Saldo</h1>
                <hr />
                <div class="row">
                    <div class="col-lg-9" id="info-paket">
                        <div class="row" id="paket-container">
                            <?php $__currentLoopData = $paket_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-3">
                                <div class="card" id="<?php echo e($paket->id); ?>">
                                    <div class="card-body d-flex flex-column justify-content-between">
                                        <h4 class="card-title"><?php echo e($paket->nama); ?></h4>
                                        <div>
                                            <h6 class="mb-2 d-flex justify-content-between nominal-paket">Nominal: <span class="thousand-separator"><?php echo e($paket->nominal); ?></span></h6>
                                            <h6 class="mb-2 text-muted d-flex justify-content-between harga-paket">Harga: <span class="thousand-separator"><?php echo e($paket->harga); ?></span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-3">
                                <div class="card" id="manual">
                                    <div class="card-body d-flex flex-column justify-content-between">
                                        <h4 class="card-title mb-1">Manual</h4>
                                        <input id="input-manual" type="number" class="form-control mb-2" min="0" step="100" value="0"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr class="d-lg-none">
                    <div class="col-lg-3 border-start" id="info-pelanggan">
                        <div class="mb-2">
                            <h5>Pelanggan</h5>
                            <div>
                                <input id="nama-pelanggan" list="data-pelanggan" class="form-control">
                                <datalist id="data-pelanggan">
                                    <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pelanggan->nama); ?>" data-id="<?php echo e($pelanggan->id); ?>"></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                        <div class="mb-2">
                            <h5>Saldo Akhir</h5>
                            <input id="input-saldo-akhir" type="text" class="form-control disabled" min="0" />
                        </div>
                        <div class="mb-2">
                            <h5>Dibayarkan</h5>
                            <input id="input-dibayarkan" type="text" class="form-control disabled" min="0" value="0" />
                        </div>
                        <div class="text-end">
                            <button id="submit-saldo" class="btn btn-primary" type="button">Beli</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="<?php echo e(asset('js/transaksi/saldo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/pages/transaksi/saldo.blade.php ENDPATH**/ ?>