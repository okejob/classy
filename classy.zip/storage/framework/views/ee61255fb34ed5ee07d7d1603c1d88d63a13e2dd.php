<div class="table-responsive my-2 tbody-wrap">
    <table class="table table-striped mb-0" id="table-trans-item">
        <thead>
            <tr>
                <th>Nama Item</th>
                <th class="d-none d-lg-table-cell">Kategori</th>
                <th class="d-none d-md-table-cell">Proses</th>
                <th class="d-none d-md-table-cell">Qty</th>
                <th class="d-none d-md-table-cell">Bobot</th>
                <th>Total</th>
                <th style="width: 46.25px;"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trans->item_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id='<?php echo e($item->id); ?>'>
                <td style='white-space: nowrap;'><?php echo e($item->nama); ?></td>
                <td class='d-none d-lg-table-cell text-center'><?php echo e($item->nama_kategori); ?></td>
                <?php if($trans->penyetrika != null): ?>
                    <td class='d-none d-md-table-cell text-center'>Setrika</td>
                <?php elseif($trans->pencuci != null): ?>
                    <td class='d-none d-md-table-cell text-center'>Cuci</td>
                <?php else: ?>
                    <td class='d-none d-md-table-cell'></td>
                <?php endif; ?>
                <?php if(in_array("Mengubah Data Item Transaksi", Session::get('permissions')) || Session::get('role') == 'administrator'): ?>
                <td class='d-none d-md-table-cell text-center p-0 col-qty'>
                    <div class='d-flex align-items-center justify-content-center' style='height: 39.5px;'><?php echo e($item->qty); ?></div>
                </td>
                <?php else: ?>
                <td class='d-none d-md-table-cell text-center p-0 col-qty disabled'>
                    <div class='d-flex align-items-center justify-content-center' style='height: 39.5px;'><?php echo e($item->qty); ?></div>
                </td>
                <?php endif; ?>
                <td class='d-none d-md-table-cell text-center'><?php echo e($item->bobot_bucket); ?></td>
                <td class='text-center'><?php echo e($item->total_bobot); ?></td>
                <td class='text-end' style='width: 46.25px;'>
                    <button id='btn-<?php echo e($item->id); ?>' class='btn btn-primary btn-sm btn-show-action' type='button'>
                        <i class='fas fa-bars' aria-hidden='true'></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array("Menambahkan Item Transaksi", Session::get('permissions')) || Session::get('role') == 'administrator'): ?>
            <tr>
                <td class="text-center" colspan="7" style="padding-top: 4px;padding-bottom: 4px;">
                    <button class="btn btn-primary btn-sm" id="add-item" type="button">
                        <i class="fas fa-plus"></i>
                    </button>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td class="text-end">Sub Total</td>
                <td style="width: 5%">Rp</td>
                <td class="text-end thousand-separator" id="sub-total"><?php echo e($trans->subtotal); ?></td>
                <td style="width: 46.25px;"></td>
            </tr>
            <tr>
                <td class="text-end">Diskon</td>
                <td style="width: 5%">Rp</td>
                <td class="text-end thousand-separator" id="diskon"><?php echo e($trans->diskon); ?></td>
                <td style="width: 46.25px;"></td>
            </tr>
            <tr>
                <td class="text-end">Diskon Member</td>
                <td style="width: 5%">Rp</td>
                <td class="text-end thousand-separator" id="diskon-member"><?php echo e($trans->diskon_member); ?></td>
                <td style="width: 46.25px;"></td>
            </tr>
            <tr>
                <td class="text-end">Grand Total</td>
                <td style="width: 5%">Rp</td>
                <td class="text-end thousand-separator" id="grand-total"><?php echo e($trans->grand_total); ?></td>
                <td style="width: 46.25px;"></td>
            </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/components/tableItemTransBucket.blade.php ENDPATH**/ ?>