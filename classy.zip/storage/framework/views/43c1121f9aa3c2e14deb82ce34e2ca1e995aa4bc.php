<!DOCTYPE html>
<html>

<head>
    <title>Transaction Receipt</title>
    <style>
        /* Add any styles you want to use for the PDF here */
        body {
            font-family: Arial, sans-serif;
            font-size: 10pt
        }

        table {
            width: 100%;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }

        .hr-text {
            color: #333;
            text-align: center;
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: "";
        }

        td {
            border: none !important;
        }
    </style>
</head>

<body>
    <div id="data-header">
        <h5> <?php echo e($data->header['nama_usaha']); ?></h5>
        <h5> <?php echo e($data->transaksi->outlet->alamat); ?></h5>
        <h5> <?php echo e($data->header['delivery_text']); ?></h5>
        <p class="hr-text">
            ============================================================================================================================
        </p>
    </div>
    <div id="data-kasir">
        <div class="row">
            <div class="col-2">KASIR</div>
            <div class="col-3">: <?php echo e(Auth::user()->username); ?></div>
            <div class="col-2">PENCETAKAN</div>
            <div class="col-5">: <?php echo e(date('d-m-20y h:i:s')); ?></div>
        </div>
        <p class="hr-text">
            ============================================================================================================================
        </p>
    </div>
    <div id=data-transaksi>
        <div class="row">
            <div class="col-2 d-flex flex-column">
                <p>NO. ORDER</p>
                <p>PELANGGAN</p>
                <p>ALAMAT/TELP</p>
                <p>SISA SALDO</p>
            </div>
            <div class="col-10">
                <p>: <?php echo e($data->transaksi->kode); ?> / <?php echo e($data->transaksi->jenis_transaksi); ?></p>
                <p>: <?php echo e($data->transaksi->pelanggan->nama); ?> / <?php echo e($data->transaksi->pelanggan->no_id); ?></p>
                <p>: <?php echo e($data->transaksi->pelanggan->alamat); ?> / <?php echo e($data->transaksi->pelanggan->telephone); ?></p>
                <p>: <?php echo e($data->transaksi->pelanggan->saldo_akhir); ?></p>
            </div>
            <div class="col-2 text-end">
                <p>EXPRESS</p>
            </div>
            <div class="col-2">
                <p>: <?php echo e($data->transaksi->express ? 'YA' : 'TIDAK'); ?></p>
            </div>
            <div class="col-2 text-end">
                <p>SETRIKA SAJA</p>
            </div>
            <div class="col-2">
                <p>: <?php echo e($data->transaksi->setrika_only ? 'YA' : 'TIDAK'); ?></p>
            </div>
        </div>
        <p class="hr-text">
            ============================================================================================================================
        </p>
    </div>
    <div id="detail-transaksi">
        <?php if(str_contains($data->transaksi->kode, 'BU-')): ?>
            <div class="table-responsive">
                <table class="table table-sm" style="font-size: 10pt">
                    <thead>
                        <tr>
                            <th class="text-center">NAMA ITEM</th>
                            <th class="text-center">QTY</th>
                            <th class="text-center">UNIT</th>
                            <th class="text-center">BOBOT</th>
                            <th class="text-center">TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data->transaksi->item_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start"><?php echo e($item->nama); ?></td>
                                <td class="text-center"><?php echo e($item->qty); ?></td>
                                <td class="text-center"><?php echo e($item->satuan_unit); ?></td>
                                <td class="text-center"><?php echo e($item->bobot_bucket); ?></td>
                                <td class="text-center"><?php echo e($item->total_bobot); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Subtotal</td>
                            <td class="text-end thousand-separator"><?php echo e($data->transaksi->subtotal); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Diskon</td>
                            <td class="text-end thousand-separator">
                                <?php echo e($data->transaksi->diskon + $data->transaksi->diskon_member); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Grand Total</td>
                            <td class="text-end thousand-separator"><?php echo e($data->transaksi->grand_total); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php elseif(str_contains($data->transaksi->kode, 'PR-')): ?>
            <div class="table-responsive">
                <table class="table table-sm" style="font-size: 10pt">
                    <thead>
                        <tr>
                            <th class="text-center">NAMA ITEM</th>
                            <th class="text-center">QTY</th>
                            <th class="text-center">UNIT</th>
                            <th class="text-center">HARGA</th>
                            <th class="text-center">TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data->transaksi->item_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start"><?php echo e($item->nama); ?></td>
                                <td class="text-center"><?php echo e($item->qty); ?></td>
                                <td class="text-center"><?php echo e($item->satuan_unit); ?></td>
                                <td class="text-end thousand-separator"><?php echo e($item->harga_premium / $item->qty); ?></td>
                                <td class="text-end thousand-separator"><?php echo e($item->harga_premium); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Subtotal</td>
                            <td class="text-end thousand-separator"><?php echo e($data->transaksi->subtotal); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Diskon</td>
                            <td class="text-end thousand-separator">
                                <?php echo e($data->transaksi->diskon + $data->transaksi->diskon_member); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Grand Total</td>
                            <td class="text-end thousand-separator"><?php echo e($data->transaksi->grand_total); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
        <p class="hr-text">
            ============================================================================================================================
        </p>
    </div>

</body>

</html>
<?php /**PATH D:\OKEJOB PROJECT\classy\resources\views/pages/print/template.blade.php ENDPATH**/ ?>