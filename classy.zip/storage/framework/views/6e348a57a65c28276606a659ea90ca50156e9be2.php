

<?php $__env->startSection('content'); ?>
<section class="bg-clean vh-100 d-flex align-items-center">
    <form method="post" action="/login">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <div class="px-2 mb-1 d-flex justify-content-between align-items-center form-container">
                <input class="form-control" type="text" placeholder="Username" name="username" required>
            </div>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="padding: 0.5rem 1.15rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <div class="ps-2 mb-1 d-flex justify-content-between align-items-center form-container">
                <input class="form-control px-2" type="password" name="password" placeholder="Password" required>
                <button class="btn h-100" type="button" style="box-shadow: none;"><i class="fas fa-eye-slash"></i></button>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="padding: 0.5rem 1.15rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-3">
            <button class="btn btn-primary d-block w-100" type="submit">Log In</button>
        </div>
    </form>
</section>
<script>
    $(document).ready(function() {
        document.cookie = "";
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\classy\resources\views/pages/session/login.blade.php ENDPATH**/ ?>