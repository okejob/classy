<h5>Outlet</h5>
<select class="form-select" required>
    <option value="" hidden>-</option>
    <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(Auth::user()->outlet && Auth::user()->outlet->id == $outlet->id): ?>
            <option value=<?php echo e($outlet->id); ?> selected><?php echo e($outlet->nama); ?></option>
        <?php else: ?>
            <option value=<?php echo e($outlet->id); ?>><?php echo e($outlet->nama); ?></option>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\xampp\htdocs\classy\resources\views/components/selectOutlet.blade.php ENDPATH**/ ?>