<!doctype html>
<html>
<head>
    @include('includes.head')
</head>
<body>
    <div id="content" class="w-100">
        @yield('content')
    </div>
</body>
</html>
