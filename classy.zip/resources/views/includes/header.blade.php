<header id="header" class="bg-main d-flex align-items-center justify-content-between px-2">
    <button class="btn" type="button">
        <i id="side-icon" class="fas fa-bars"></i>
    </button>
    <div>
        <div class="dropdown">
            <button class="btn dropdown-toggle" aria-expanded="false" data-bs-toggle="dropdown" type="button">
                <i class="fas fa-user-circle"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
                <a class="dropdown-item" href="/logout">Log Out</a>
            </div>
        </div>
    </div>
</header>
