$(document).ready(function() {

    $('#create-pickup').on('click', function() {
        $('#modal-create-pickup').modal('show');
    });

    $('#create-delivery').on('click', function() {
        $('#modal-create-delivery').modal('show');
    });
});
